import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { AnagraficaWrapperComponent } from './anagrafica-wrapper/anagrafica-wrapper.component';
import { ContainerComponent } from './container/container.component';
import { FooterComponent } from './footer/footer.component';
import { HeaderComponent } from './header/header.component';



@NgModule({
  declarations: [
    
    ContainerComponent,
    AnagraficaWrapperComponent,
    FooterComponent,
    HeaderComponent
   ],
  imports: [
    CommonModule,
    BrowserModule
  ]
})
export class LayuotModule { }
