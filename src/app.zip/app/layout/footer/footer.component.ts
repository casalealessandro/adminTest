import { Component, Input, OnInit } from '@angular/core';
import { messagefromComponent } from '../../class/appinterface';
import { ComponentService } from '../../services/component.service';

import { UserService } from '../../services/user.service';

@Component({
    selector: 'app-footer',
    templateUrl: './footer.component.html',
    styleUrls: ['./footer.component.scss']
})
export class FooterComponent implements OnInit {

    @Input() idTipoUtente

    dateCopy: Date;
    infoAziendaFooter;
    infoLicenzaOwner;
    infoAziendaFooterDescLicenza: string;
    infoAziendaFooterCodiceLicenza: string;
    showFooter: true;
    constructor(public utenteService: UserService, private componentService: ComponentService) { }

    ngOnInit() {

        this.dateCopy = new Date();


        if (this.idTipoUtente == 2) {
            this.infoLicenzaOwner = this.utenteService.InfoUtenteConnesso.licenza + ' - ' + this.utenteService.InfoUtenteConnesso.descr_licenza


        } else if (this.idTipoUtente > 2) {

            let aziendaSelected = this.utenteService.InfoUtenteConnesso['aziendaSelected'];
            this.showFooter = true
            //alert(this.utenteService.InfoUtenteConnesso['licenza']);
            this.infoAziendaFooter = this.utenteService.InfoUtenteConnesso['aziende'].find(aziende => {
                return aziende.id == aziendaSelected
            });
            this.infoAziendaFooterCodiceLicenza = this.utenteService.InfoUtenteConnesso['licenza']
            this.infoAziendaFooterDescLicenza = this.utenteService.InfoUtenteConnesso['descr_licenza']
        }



        //console.log(this.utenteService.InfoUtenteConnesso)
    }
}
