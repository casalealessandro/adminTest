import { Component, Input } from '@angular/core';
import { SelectionChangedEvent, ValueChangedEvent } from 'devextreme/ui/select_box';


import { UserService } from '../../services/user.service';
import { environment } from '../../../environments/environment';
import { Router } from '@angular/router';
import { ComponentService } from '../../services/component.service';
import { alert, confirm } from '../../widgets/ui-dialogs';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrl: './header.component.scss'
})


export class HeaderComponent {

  AziendaDiLavoro: any;


  @Input() idTipoUtente;

  menuAdmin: boolean = true;

  DescrizioneLicenza: any;
  NumTabsOpen: any;
  apiDocLink: string = environment.PUBLIC_API_DOCUMENTATION;
  currenAnnoRiferimento: any;
  headerOption: any = [];
  AnniRiferimento: any = [];
  DB: any;
  menusUtente: any;
  foto: any = "assets/images/img_avatar2.png";
  constructor(private utenteService: UserService, private router: Router, private componentService: ComponentService) {

    this.utenteService.tipoUtente.subscribe(resTipoutente => {
      this.idTipoUtente = resTipoutente;
      this.renderHeader()
    })
  }

  ngOnInit() {
    this.renderHeader()
  }


  renderHeader() {
    this.headerOptions(this.idTipoUtente);
    this.getAnniRiferimento(this.utenteService.InfoUtenteConnesso.aziendaSelectedAnnoInstallazione);

    this.DB = this.utenteService.InfoUtenteConnesso.aziende;
    this.AziendaDiLavoro = this.utenteService.InfoUtenteConnesso.aziendaSelected;

    this.menuUtente();
  }

  menuUtente() {
    let value = this.utenteService.InfoUtenteConnesso;

    if (value['foto']) {
      this.foto = environment.BASE_PUBLIC_IMAGE + value['foto'] + "?time=" + new Date().getTime();
    }

    this.menusUtente =
    {
      text: "",
      value: 'header',
      src: this.foto,//assets/images/img_avatar2.png
      items: []

    }

    switch (this.idTipoUtente) {
      case 1:
        this.menusUtente.items.push(
          { itemIndex: 2, text: "Esci dalla Piattaforma", value: "logout", icon: "icon-log-out", },
        )
        break;

      case 3:
        this.menusUtente.items.push(
          { itemIndex: 1, text: "Modifica Profilo", value: "profilo", icon: 'icon-username', class: 'imageProfileHeader' },
          { itemIndex: 3, text: "Informazioni su Licenza", value: "info", icon: "icon-info" },
          { itemIndex: 2, text: "Esci dalla Piattaforma", value: "logout", icon: "icon-log-out", }
        )
        break
      default:
        this.menusUtente.items.push(
          { itemIndex: 1, text: "Modifica Profilo", value: "profilo", icon: 'icon-username', class: 'imageProfileHeader' },

          { itemIndex: 3, text: "Informazioni su Licenza", value: "info", icon: "icon-info" },
          { itemIndex: 2, text: "Esci dalla Piattaforma", value: "logout", icon: "icon-log-out", }
        )
        break;
    }


  }




  headerOptions(tipo) {


    switch (tipo) {

      case 1:

        this.headerOption.selAzienda = false;
        this.headerOption.selLicenze = false;
        this.headerOption.selDB = false;
        this.headerOption.logo = true;
        this.headerOption.hideMenu = false;
        this.headerOption.hideBackIcon = false;
        this.headerOption.linkHome = "#/owner";
        this.headerOption.dashLabel = "Admin";
        this.headerOption.prefMenu = false;
        this.headerOption.swaggerTemp = !environment.production;
        this.headerOption.menuTheme = false;
        this.headerOption.menuProfile = true;
        this.headerOption.listaPopup = false;
        this.headerOption.EmailComponent = false;
        this.headerOption.listaComuni = false;
        this.headerOption.listaCer = false;
        this.headerOption.setting = false;
        this.headerOption.styleOption = { padding: '1px 10px' };

        break;
      case 2:

        this.headerOption.logo = true;
        this.headerOption.hideMenu = false;
        this.headerOption.hideBackIcon = false;
        this.headerOption.linkHome = "#/owner";
        this.headerOption.dashLabel = "Admin";
        this.headerOption.prefMenu = false;
        this.headerOption.swaggerTemp = !environment.production;
        this.headerOption.menuTheme = false;
        this.headerOption.menuProfile = true;
        this.headerOption.listaPopup = false;
        this.headerOption.EmailComponent = false;
        this.headerOption.listaComuni = false;
        this.headerOption.listaCer = false;
        this.headerOption.setting = false;
        this.headerOption.selAzienda = true;
        this.headerOption.selLicenze = false;
        this.headerOption.selDB = false;

        this.headerOption.styleOption = { padding: '1px 10px' };


        break;
      case 3:

        this.headerOption.logo = true;
        this.headerOption.hideMenu = true;
        this.headerOption.hideBackIcon = false;
        this.headerOption.linkHome = "/";
        this.headerOption.dashLabel = "Dashboard";
        this.headerOption.prefMenu = true;
        this.headerOption.swaggerTemp = !environment.production;
        this.headerOption.menuTheme = false;
        this.headerOption.menuProfile = true;
        this.headerOption.listaPopup = true;
        this.headerOption.EmailComponent = true;
        this.headerOption.selAzienda = false;
        this.headerOption.selLicenze = false;
        this.headerOption.selDB = true;

        this.headerOption.listaComuni = true;
        this.headerOption.listaCer = true;
        this.headerOption.setting = false;
        this.headerOption.styleOption = '';

        this.menuAdmin = false
        break;
      case 4:
      case 5:
        this.headerOption.logo = true;
        this.headerOption.hideMenu = true;
        this.headerOption.hideBackIcon = true;
        this.headerOption.linkHome = "/";
        this.headerOption.dashLabel = "Dashboard";
        this.headerOption.prefMenu = true;
        this.headerOption.swaggerTemp = !environment.production;
        this.headerOption.menuTheme = false;
        this.headerOption.menuProfile = true;
        this.headerOption.listaPopup = true;
        this.headerOption.EmailComponent = true;
        this.headerOption.selAzienda = false;
        this.headerOption.selLicenze = false;
        this.headerOption.selDB = true;

        this.headerOption.listaComuni = true;
        this.headerOption.listaCer = true;
        this.headerOption.setting = false;
        this.headerOption.styleOption = '';
        break;
      default:

        this.headerOption.logo = true;
        this.headerOption.hideMenu = false;
        this.headerOption.hideBackIcon = true;
        this.headerOption.linkHome = "/";
        this.headerOption.dashLabel = "Dashboard";
        this.headerOption.prefMenu = false;
        this.headerOption.swaggerTemp = true;
        this.headerOption.menuTheme = false;
        this.headerOption.menuProfile = false;
        this.headerOption.listaPopup = false;
        this.headerOption.EmailComponent = false;
        this.headerOption.listaComuni = false;
        this.headerOption.selAzienda = false;
        this.headerOption.selLicenze = false;
        this.headerOption.selDB = true;

        this.headerOption.listaCer = false;
        this.headerOption.setting = true;
        this.headerOption.styleOption = {  padding: '1px 10px' };

        break;
    }


  }


  getAnniRiferimento(aziendaSelectedAnnoInstallazione) {


    //this.utenteService.InfoUtenteConnesso.aziendaSelectedAnnoInstallazione
    const currentYear = new Date().getFullYear();
    for (var i = aziendaSelectedAnnoInstallazione; i <= currentYear + 1; i++) {
      this.AnniRiferimento.push(i + "");
    }
    this.currenAnnoRiferimento = currentYear;
  }


  HoCambiatoAnno($event: SelectionChangedEvent) {
    throw new Error('Method not implemented.');
  }


  HoCambiatoAzienda(e) {
    const idLicenza = this.utenteService.InfoUtenteConnesso.licenza;


    sessionStorage.removeItem('currentTabsItems')
    sessionStorage.removeItem('navComponent')
    let idAzienda = e.value
    this.router.navigate(['/login', idAzienda]);
    /* this.router.navigate(["login"], {
        
        queryParams:{
        idAzienda:e.value,   
        idLicenza: idLicenza
         },
         skipLocationChange: true,
         replaceUrl: true
       }                
     )
*/
    return
  }

  selectOpUtente(event, value) {

    event.preventDefault()
    event.stopPropagation()

    let index = value.itemIndex
    switch (index) {
     
      case 1:
        let queryString = '/'+ this.utenteService.InfoUtenteConnesso.idAccount;
        let dataInstanceProfilo = {
          api: 'account',
          service:'profiloForm',
          isEdit:true,
          queryString:queryString,
          labelWidth:125,
          standardBtnBottom:[15,0]
        }

        let profiloDesc = this.idTipoUtente == 1 ? 'Owner' : (this.idTipoUtente == 2 ? 'Super Administrator'  : this.idTipoUtente == 3 ? 'Administrator' : '')
        const titoloFormProfilo = `Profilo ${profiloDesc} `

        this.componentService.setNewPopUp(null, 'NewNicaFormComponent', null, 810, null, dataInstanceProfilo,false,true, titoloFormProfilo)

      break;

      case 2:
        confirm("<i style='font-size:24px;margin-right: 50px' class='icon dx-icon-runner'></i><i>Sicuro?</i>", "Conferma il logout", (dialogResult) => {
          if (dialogResult) {

            this.utenteService.LogOut().then(result => {
              this.utenteService.clearSessionStorage()

              this.router.navigate(['/login'], {
                skipLocationChange: true,
                replaceUrl: true
              }).then(() => {
                window.location.reload();
              });


            })


          }

        });
        break;
      case 3:
        let dataInstance = {
          utenteAttuale: this.utenteService.InfoUtenteConnesso
        }
        this.componentService.setNewPopUp(null, 'NicaLicenzaInfoComponent', null, 450, null, dataInstance, true, true, 'Informazioni su Licenza')

        break;

      default:
        break;
    }


    if (value.itemIndex == 2) {

    }
    if (value.itemIndex == 1) { //Modifica Profilo

      //this.popupVisible = true;
    }



  }


}