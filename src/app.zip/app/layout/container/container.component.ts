import { Component } from '@angular/core';


@Component({
  selector: 'app-container',
  standalone:false,
  templateUrl: './container.component.html',
  styleUrl: './container.component.scss'
})
export class ContainerComponent {
  isClose: boolean = false;
  isLogin:boolean = false;
  idTipoUtente: number = -1;
  subMenu: any = null;
  currentMainMenuActive: any;
  showSubMenu: boolean = false;

  
  constructor() {}

  ngOnInit() {

    
  }
  

 
   
}
