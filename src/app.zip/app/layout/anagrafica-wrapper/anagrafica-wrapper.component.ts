import { Component, Input, OnInit, Output, EventEmitter, ViewChild, AfterViewInit } from '@angular/core';
import { ToolbarComponent } from '../../components/toolbar/toolbar.component';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';



@Component({
  selector: 'app-anagrafica-wrapper',
  templateUrl: './anagrafica-wrapper.component.html',
  styleUrls: ['./anagrafica-wrapper.component.scss']
})
export class AnagraficaWrapperComponent {

  @ViewChild('toolbarTab', { static: true }) toolbarTab:ToolbarComponent


  @Output() emettiChiusura: EventEmitter<any> = new EventEmitter<any>();
  @Output() emitToolbarLeft: EventEmitter<any> = new EventEmitter<any>();



  @Input() showBreadcrumb: boolean = false;
  @Input() caption: string = 'false';
  @Input() cssClass: string = '';

  @Input() helpDoc: string = '';
  @Input() breadcrumbCaption: string = '';
  @Input() breadcrumbGroup: any= '';
  @Input() breadcrumbNavigation: any= [];
  @Input() isClosable: boolean = false
  @Input() currentTemplate: any ='grid';
  @Input() footerVisible: boolean = true;
  @Input() isPopUp: boolean = false;

  @Input() showToolBar: boolean = true; 

  @Input() backgroundToolbar!: string;
  @Input() textColorToolbar!: string;
  @Input() buttonToolbarUp: any = [];
  @Input() buttonToolbarBottom: any= [];
  @Input() customButtonToolbarBottom: any= [];
  @Input() customButtonToolbarTop: any= [];
  @Input() isOpen: boolean = false;
  @Input() id: string = '';
  @Input() InAttesaOpen: boolean = false;
  @Input() customizationClass: string = ''
  @Input() tabsService: string = '';
  @Input() anaService: string = '';

  public timeInterval: any = 0;

  heightWrap!: number;
  itemTabs: any = [];
  showItemsTabs:boolean=false
  private tabSubscription: Subscription | undefined;
  
  constructor() {}


  ngAfterViewInit(){
    this.getWindowHeight()
    
  }


  ngOnInit(): void {

    if (typeof this.id == 'undefined') {
      this.id = ''
    }

    
   
  }

  ngOnDestroy() {
    // Ricordati di annullare la sottoscrizione per evitare memory leaks
    if (this.tabSubscription) {
      this.tabSubscription.unsubscribe();
    }
  }

  getWindowHeight() {

    const windowHeight = window.innerHeight;
    const documentHeight = document.documentElement.clientHeight;
  
    // Altezza massima tra l'altezza della finestra e l'altezza del documento

    const heightWin  = Math.max(windowHeight, documentHeight);

    let  headerHeight, footerHeight ,menuHeight;
    headerHeight = document.getElementById('header').offsetHeight;
    footerHeight = document.getElementById('footer').offsetHeight;
    setTimeout(() => {
      menuHeight = document.getElementById('horizontalMenucontainer').offsetHeight 
 
      if(menuHeight == 0){
        menuHeight = 60.5
      }
     
     
      this.heightWrap = heightWin - headerHeight - footerHeight - menuHeight ;   
      this.heightWrap = this.heightWrap  - 13;
     }, 300);
   
    
  }
  

 
  onCrocettaClick(evt) {



    

    if (evt == 'closeToolbar') {


      if (!this.isOpen) {
        this.openToolBar();

      } else {
        this.closeToolBar();
      }

    }else{
      this.emettiChiusura.emit(evt);
    }

  }



  openToolBar(event?) {
    if (typeof event != 'undefined') {
      event.preventDefault();
      event.stopPropagation();
    }

    this.InAttesaOpen = true;
    this.timeInterval = setTimeout(() => {
      if (!this.isOpen && this.InAttesaOpen)

        this.isOpen = true
    }, 100);



  }
  closeToolBar(event?) {

    if (typeof event != 'undefined') {
      event.preventDefault();
      event.stopPropagation();
    }
    this.InAttesaOpen = false;
    clearTimeout(this.timeInterval);
    setTimeout(() => {
      if (this.isOpen)
        this.isOpen = false

    }, 100);


  }

  buttonToolbarLeft(event) {

    this.emitToolbarLeft.emit(event)

  }
}
